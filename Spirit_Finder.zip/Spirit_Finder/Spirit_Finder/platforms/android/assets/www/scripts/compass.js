﻿//compass.js

var watchID;

var element = document.getElementById('compass');
var compassImg = document.getElementById('compassimg');

function onSuccess(heading) {
    if (heading.magneticHeading >= 343.13 || heading.magneticHeading <= 28.12 ){
        compassImg.src = "images/North.png";
        compassImg.alt = "North";
    } else if (heading.magneticHeading >= 28.13 && heading.magneticHeading <= 73.12){
        compassImg.src = "images/NorthEast.png";
        compassImg.alt = "North East";
    } else if (heading.magneticHeading >= 73.13 && heading.magneticHeading <= 118.12){
        compassImg.src = "images/East.png";
        compassImg.alt = "East";
    } else if (heading.magneticHeading >= 118.13 && heading.magneticHeading <= 163.12 ){
        compassImg.src = "images/SouthEast.png";
        compassImg.alt = "South East";
    } else if (heading.magneticHeading >= 163.13 && heading.magneticHeading <= 208.12){
        compassImg.src = "images/South.png";
        compassImg.alt = "South";
    } else if (heading.magneticHeading >= 208.13 && heading.magneticHeading <= 253.12 ){
        compassImg.src = "images/SouthWest.png";
        compassImg.alt = "South West";
    } else if (heading.magneticHeading >= 253.13 && heading.magneticHeading <= 298.12 ){
        compassImg.src = "images/West.png";
        compassImg.alt = "West";
    } else if (heading.magneticHeading >= 298.13 && heading.magneticHeading <= 343.12 ){
        compassImg.src = "images/NorthWest.png";
        compassImg.alt = "North West";
    }
   // element.innerHTML = heading.magneticHeading;
};

function onError(compassError) {
    element.innerHTML = 'Compass error: ' + compassError.code;
};

var options = {
    frequency: 1000
}; // Update every 1 seconds

function initCompass() {
    watchID = navigator.compass.watchHeading(onSuccess, onError, options);
}

function stopCompass() {
    if (watchID != null){
      navigator.compass.clearWatch(watchID);
      watchID = null;
    }
   
}


/* document.addEventListener("deviceready", onDeviceReady, false);
function onDeviceReady() {
    initCompass();
};
*/


