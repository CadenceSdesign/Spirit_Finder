﻿// light.js

//document.addEventListener('deviceready', onDeviceReady, false);

/*
//light
function onDeviceReady() {
    $(".divButtons").show();
};

$(".flight").click(function () {
    if (this.value == "ON") {
        //button on clicked
        $("#btnLight").addClass("toggledOn");
        window.plugins.flashlight.switchOn();
    } else {
        //button off clicked
        $("#btnLight").removeClass("toggledOn");
        $("#btnLight").value="OFF";
        window.plugins.flashlight.switchOff();
    }
});
*/

var btnLight = document.getElementById("btnLight");
var candleLight = "off"
function changeLight() {
    if (candleLight === "off"){
        btnLight.src = "images/candleLit.png";
        window.plugins.flashlight.switchOn();
        candleLight = "on";
    } else {
        btnLight.src = "images/candleUnlit.png";
        window.plugins.flashlight.switchOff();
        candleLight = "off";
    }
}